@section('formatos')
<div class="container">
	<div class="row">
		<div class="bottom-padding col-sm-6 col-md-6">
			<div class="title-box">
				<h2 class="title">Open a few toggles at a time</h2>
			</div>

			<div class="panel-group multi-collapse" id="accordion2">
				<div class="panel panel-default active">
					<div class="panel-heading">
						<div class="panel-title">
							<a data-toggle="collapse" data-parent="#accordion2" href="#collapse21">
								Portfolio Pages
							</a>
						</div>
					</div>
					<div id="collapse21" class="panel-collapse collapse in">
						<div class="panel-body">
							<img src="img/content/animations-100.png" class="alignright" width="100" height="62" alt="">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores ipsa esse obcaecati repudiandae veniam amet modi recusandae optio earum sequi accusantium culpa vitae iste sit commodi eaque voluptatem officia quam.
						</div>
					</div>
				</div>

				<div class="panel panel-default active">
					<div class="panel-heading">
						<div class="panel-title">
							<a data-toggle="collapse" data-parent="#accordion2" href="#collapse22">
								Gallery Pages
							</a>
						</div>
					</div>
					<div id="collapse22" class="panel-collapse collapse in">
						<div class="panel-body">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque natus quaerat voluptate? Asperiores hic dolore voluptate corporis obcaecati reiciendis sunt ipsam iste. Eligendi inventore voluptatibus quia saepe odit deserunt nam?
						</div>
					</div>
				</div>

				<div class="panel panel-default">
					<div class="panel-heading">
						<div class="panel-title">
							<a data-toggle="collapse" data-parent="#accordion2" href="#collapse23">
								Styles Pages
							</a>
						</div>
					</div>
					<div id="collapse23" class="panel-collapse collapse">
						<div class="panel-body">
							<img src="img/content/animations.png" class="alignleft" width="100" height="62" alt="">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores ipsa esse obcaecati repudiandae veniam amet modi recusandae optio earum sequi accusantium culpa vitae iste sit commodi eaque voluptatem officia quam. Molestiae nobis quidem atque explicabo eum facilis libero porro in fugiat pariatur molestias maiores voluptates rerum ipsa architecto quae assumenda harum fuga modi accusantium nihil dolor consequatur totam commodi quam quas neque dolorem veritatis unde adipisci ad illo excepturi quia facere reprehenderit non alias cum minima labore quo repudiandae perferendis?
						</div>
					</div>
				</div>

				<div class="panel panel-default">
					<div class="panel-heading">
						<div class="panel-title">
							<a data-toggle="collapse" data-parent="#accordion2" href="#collapse24">
								Shop Pages
							</a>
						</div>
					</div>
					<div id="collapse24" class="panel-collapse collapse">
						<div class="panel-body">
							<img src="img/content/animations.png" class="alignleft" width="100" height="62" alt="">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores ipsa esse obcaecati repudiandae veniam amet modi recusandae optio earum sequi accusantium culpa vitae iste sit commodi eaque voluptatem officia quam. Molestiae nobis quidem atque explicabo eum facilis libero porro in fugiat pariatur molestias maiores voluptates rerum ipsa architecto quae assumenda harum fuga modi accusantium nihil dolor consequatur totam commodi quam quas neque dolorem veritatis unde adipisci ad illo excepturi quia facere reprehenderit non alias cum minima labore quo repudiandae perferendis?
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="bottom-padding col-sm-6 col-md-6">
			<div class="carousel-box load overflow" data-carousel-pagination="true" data-carousel-nav="false" data-carousel-one="true">
				<div class="title-box">
					<a class="next" href="#">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="9px" height="16px" viewBox="0 0 9 16" enable-background="new 0 0 9 16" xml:space="preserve">
							<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#fcfcfc" points="1,0.001 0,1.001 7,8 0,14.999 1,15.999 9,8 "></polygon>
						</svg>
					</a>
					<a class="prev" href="#">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="9px" height="16px" viewBox="0 0 9 16" enable-background="new 0 0 9 16" xml:space="preserve">
							<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#fcfcfc" points="8,15.999 9,14.999 2,8 9,1.001 8,0.001 0,8 "></polygon>
						</svg>
					</a>
					<h2 class="title">Posts</h2>
				</div>

				<div class="clearfix"></div>

				<div class="row">
					<div class="carousel no-responsive">
						<div class="post">
							<h2 class="entry-title"><a href="/blog-view.html">Lorem ipsum dolor sit.</a></h2>
							<div class="entry-content">
								Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi facere earum quis ipsa vitae qui minima esse ducimus dolorum iste nisi laborum repellat dolores dolore debitis adipisci nemo quia autem pariatur a voluptatem dignissimos maiores accusantium nobis tempora consequatur cumque quas ea doloribus deleniti. Quibusdam commodi laboriosam error temporibus iste ipsa soluta distinctio maiores ad totam beatae incidunt veritatis enim? Reiciendis voluptate cupiditate asperiores ratione laboriosam alias mollitia eaque labore aperiam similique reprehenderit assumenda quidem eos explicabo rerum. Porro at ex magni aliquam laborum delectus voluptate officia modi nam et cupiditate culpa asperiores eaque fuga quae. Dolorum commodi labore neque fuga totam voluptate vitae ea laudantium iure quos placeat accusamus.
							</div>

							<div class="entry-meta">
								<span class="autor-name">Mike Example</span>,
								<span class="time">03.11.2012</span>
								<span class="separator">|</span>
								<span class="meta">Posted in <a href="#">Sports</a>, <a href="#">Movies</a></span>
								<span class="comments-link pull-right">
									<a href="#">3 comment(s)</a>
								</span>
							</div>
						</div>

						<div class="post">
							<h2 class="entry-title"><a href="/blog-view.html">Lorem ipsum dolor sit.</a></h2>
							<div class="entry-content">
								Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi facere earum quis ipsa vitae qui minima esse ducimus dolorum iste nisi laborum repellat dolores dolore debitis adipisci nemo quia autem pariatur a voluptatem dignissimos maiores accusantium nobis tempora consequatur cumque quas ea doloribus deleniti. Quibusdam commodi laboriosam error temporibus iste ipsa soluta distinctio maiores ad totam beatae incidunt veritatis enim? Reiciendis voluptate cupiditate asperiores ratione laboriosam alias mollitia eaque labore aperiam similique reprehenderit assumenda quidem eos explicabo rerum. Porro at ex magni aliquam laborum delectus voluptate officia modi nam et cupiditate culpa asperiores eaque fuga quae. Dolorum commodi labore neque fuga totam voluptate vitae ea laudantium iure quos placeat accusamus.
							</div>

							<div class="entry-meta">
								<span class="autor-name">Mike Example</span>,
								<span class="time">03.11.2012</span>
								<span class="separator">|</span>
								<span class="meta">Posted in <a href="#">Sports</a>, <a href="#">Movies</a></span>
								<span class="comments-link pull-right">
									<a href="#">3 comment(s)</a>
								</span>
							</div>
						</div>
					</div>
				</div>

				<div class="clearfix"></div>

				<div class="pagination switches"></div>
			</div>
		</div>

		
	</div>
</div>
@stop