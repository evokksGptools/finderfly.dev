@section('services')
<div class="container">
	<div class="row services">
		<div class="col-sm-12 col-md-12">
			<div class="title-box">
				<h1 class="title">Services</h1>
			</div>
		</div>

		<div class="big-services-box col-sm-4 col-md-4">
			<div>
				<div class="big-icon bg" data-appear-animation="wobble"><i class="fa fa-picture-o"></i></div>
				<h4 class="title" data-appear-animation="bounceInLeft">Web Design</h4>
				<div class="text-small" data-appear-animation="bounceInLeft">
					Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat.
					<div class="clearfix"></div><br>
					<button class="btn btn-default">Read more</button>
				</div>
			</div>
		</div><!-- .services-box-two -->

		<div class="big-services-box col-sm-4 col-md-4">
			<div>
				<div class="big-icon bg" data-appear-animation="wobble"><i class="fa fa-wrench"></i></div>
				<h4 class="title" data-appear-animation="bounceInUp">Graphic Design</h4>
				<div class="text-small" data-appear-animation="bounceInUp">
					The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those intereste. It is a long established fact that a reader.
					<div class="clearfix"></div><br>
					<button class="btn btn-default">Read more</button>
				</div>
			</div>
		</div><!-- .services-box-two -->

		<div class="big-services-box col-sm-4 col-md-4">
			<div>
				<div class="big-icon bg" data-appear-animation="wobble"><i class="fa fa-bug"></i></div>
				<h4 class="title" data-appear-animation="bounceInRight">Internet Marketing</h4>
				<div class="text-small" data-appear-animation="bounceInRight">
					The readable content of a page when looking at its layout. The point of using. Duis aute irure dolor reprehenderit in voluptate velit esse cillum.
					<div class="clearfix"></div><br>
					<button class="btn btn-default">Read more</button>
				</div>
			</div>
		</div><!-- .services-box-two -->
	</div>
	<br><br>
</div>
@stop