@section('todos_anunciantes')
<div class="container">
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem velit quos hic corrupti quis laborum cumque quaerat voluptatibus voluptates ipsum? Nisi enim veniam velit aspernatur explicabo deserunt voluptates illum quam facere voluptas delectus consequuntur dolorum magni odit est provident sequi repellendus iusto assumenda neque quo laboriosam ratione quis consequatur eligendi quae corporis distinctio vel adipisci commodi quas fugit quisquam in.</p>

	<div class="title-box">
		<h2 class="title">Our best clients</h2>
	</div>

	<div class="row bottom-padding">
		<div class="col-xs-6 col-sm-3 col-md-2 text-center">
			<a href="#" class="client" data-toggle="tooltip" data-placement="top" title="Google">
				<img src="img/content/clients/google.png" width="170" height="103" alt="">
			</a>
		</div>
		
		<div class="col-xs-6 col-sm-3 col-md-2 text-center">
			<a href="#" class="client" data-toggle="tooltip" data-placement="top" title="Yahoo">
				<img src="img/content/clients/yahoo.png" width="170" height="103" alt="">
			</a>
		</div>
		
		<div class="col-xs-6 col-sm-3 col-md-2 text-center">
			<a href="#" class="client" data-toggle="tooltip" data-placement="top" title="Sony">
				<img src="img/content/clients/sony.png" width="170" height="103" alt="">
			</a>
		</div>
		
		<div class="col-xs-6 col-sm-3 col-md-2 text-center">
			<a href="#" class="client" data-toggle="tooltip" data-placement="top" title="Yelp">
				<img src="img/content/clients/yelp.png" width="170" height="103" alt="">
			</a>
		</div>
		
		<div class="col-xs-6 col-sm-3 col-md-2 text-center">
			<a href="#" class="client" data-toggle="tooltip" data-placement="top" title="Virgin">
				<img src="img/content/clients/virgin.png" width="170" height="103" alt="">
			</a>
		</div>
		
		<div class="col-xs-6 col-sm-3 col-md-2 text-center">
			<a href="#" class="client" data-toggle="tooltip" data-placement="top" title="Rolex">
				<img src="img/content/clients/rolex.png" width="170" height="103" alt="">
			</a>
		</div>
		
		<div class="col-xs-6 col-sm-3 col-md-2 text-center">
			<a href="#" class="client" data-toggle="tooltip" data-placement="top" title="Nike">
				<img src="img/content/clients/nike.png" width="170" height="103" alt="">
			</a>
		</div>
		
		<div class="col-xs-6 col-sm-3 col-md-2 text-center">
			<a href="#" class="client" data-toggle="tooltip" data-placement="top" title="Nickelodeon">
				<img src="img/content/clients/nickelodeon.png" width="170" height="103" alt="">
			</a>
		</div>
		
		<div class="col-xs-6 col-sm-3 col-md-2 text-center">
			<a href="#" class="client" data-toggle="tooltip" data-placement="top" title="Microsoft">
				<img src="img/content/clients/microsoft.png" width="170" height="103" alt="">
			</a>
		</div>
		
		<div class="col-xs-6 col-sm-3 col-md-2 text-center">
			<a href="#" class="client" data-toggle="tooltip" data-placement="top" title="Instagram">
				<img src="img/content/clients/instagram.png" width="170" height="103" alt="">
			</a>
		</div>
		
		<div class="col-xs-6 col-sm-3 col-md-2 text-center">
			<a href="#" class="client" data-toggle="tooltip" data-placement="top" title="Disney">
				<img src="img/content/clients/disney.png" width="170" height="103" alt="">
			</a>
		</div>
		
		<div class="col-xs-6 col-sm-3 col-md-2 text-center">
			<a href="#" class="client" data-toggle="tooltip" data-placement="top" title="Diesel">
				<img src="img/content/clients/diesel.png" width="170" height="103" alt="">
			</a>
		</div>
		
		<div class="col-xs-6 col-sm-3 col-md-2 text-center">
			<a href="#" class="client" data-toggle="tooltip" data-placement="top" title="Converse">
				<img src="img/content/clients/converse.png" width="170" height="103" alt="">
			</a>
		</div>
		
		<div class="col-xs-6 col-sm-3 col-md-2 text-center">
			<a href="#" class="client" data-toggle="tooltip" data-placement="top" title="Cartier">
				<img src="img/content/clients/cartier.png" width="170" height="103" alt="">
			</a>
		</div>
		
		<div class="col-xs-6 col-sm-3 col-md-2 text-center">
			<a href="#" class="client" data-toggle="tooltip" data-placement="top" title="Amazon">
				<img src="img/content/clients/amazon.png" width="170" height="103" alt="">
			</a>
		</div>
		
		<div class="col-xs-6 col-sm-3 col-md-2 text-center">
			<a href="#" class="client" data-toggle="tooltip" data-placement="top" title="Nike">
				<img src="img/content/clients/nike.png" width="170" height="103" alt="">
			</a>
		</div>
		
		<div class="col-xs-6 col-sm-3 col-md-2 text-center">
			<a href="#" class="client" data-toggle="tooltip" data-placement="top" title="Google">
				<img src="img/content/clients/google.png" width="170" height="103" alt="">
			</a>
		</div>
		
		<div class="col-xs-6 col-sm-3 col-md-2 text-center">
			<a href="#" class="client" data-toggle="tooltip" data-placement="top" title="Yelp">
				<img src="img/content/clients/yelp.png" width="170" height="103" alt="">
			</a>
		</div>
	</div>
</div><!-- .container -->
@stop