@section('banner-set')
<div class="banner-set load">
	<div class="container">
		<div class="banners">
			<a href="#" class="banner">
				<img src="img/content/banner1.jpg" width="253" height="158" alt="">
				<h2 class="title">Home Theater</h2>
				<div class="description">Nunc condimentum eros vel nibh consectetur dignissim. Ut ante neque, ullamcorper ac feugiat at, ullamcorper sagittis magna.</div>
			</a>
			<a href="#" class="banner">
				<img src="img/content/banner2.jpg" width="253" height="158" alt="">
				<h2 class="title">Multiroom</h2>
				<div class="description">Maecenas ac leo velit. Aliquam venenatis tellus in erat pellentesque ut dignissim turpis consequat. Fusce sit amet sagittis urna.</div>
			</a>
			<a href="#" class="banner">
				<img src="img/content/banner3.jpg" width="253" height="158" alt="">
				<h2 class="title">Lighting Control</h2>
				<div class="description">Phasellus quis mauris non mauris sceleris vehicula. Vestibulum ipsum odio, placerat sed consequat in, congue non nibh.</div>
			</a>
			<a href="#" class="banner">
				<img src="img/content/banner4.jpg" width="253" height="158" alt="">
				<h2 class="title">Amazing Sound</h2>
				<div class="description">Maecenas et massa odio, tincidunt ultrices sapien. Praesent non tortor quis metus posuere gravida at quis nulla.</div>
			</a>
			<a href="#" class="banner">
				<img src="img/content/banner5.jpg" width="253" height="158" alt="">
				<h2 class="title">Home Theater</h2>
				<div class="description">Nunc condimentum eros vel nibh consectetur dignissim. Ut ante neque, ullamcorper ac feugiat at, ullamcorper sagittis magna.</div>
			</a>
			<a href="#" class="banner">
				<img src="img/content/banner6.jpg" width="253" height="158" alt="">
				<h2 class="title">Multiroom</h2>
				<div class="description">Maecenas ac leo velit. Aliquam venenatis tellus in erat pellentesque ut dignissim turpis consequat. Fusce sit amet sagittis urna.</div>
			</a>
		</div><!-- .banners -->
		<div class="clearfix"></div>
	</div>
	<div class="nav-box">
		<div class="container">
			<a class="prev" href="#"><span class="glyphicon glyphicon-arrow-left"></span></a>
			<div class="pagination switches"></div>
			<a class="next" href="#"><span class="glyphicon glyphicon-arrow-right"></span></a>	
		</div>
	</div>
</div><!-- .banner-set -->
@stop