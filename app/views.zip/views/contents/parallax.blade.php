@section('parallax')
<div class="full-width-box bottom-padding cm-padding-bottom-36">
					<div class="fwb-bg fwb-fixed band-5"><div class="overlay"></div></div>

					<div class="container">
						<div class="title-box title-white">
							<h1 class="title no-top-padding">Meet the Team</h1>
						</div>

						<div class="row text-center">
							<div class="col-sm-3 col-md-3 rotation employee">
								<div class="default">
									<div class="image">
										<img src="img/content/team-1.jpg" alt="" title="" width="270" height="270">
									</div>
									<div class="description">
										<div class="vertical">
											<h3 class="name">Mett Rayan</h3>
											<div class="role">Manager</div>	
										</div>
									</div>
								</div>
								<div class="employee-hover">
									<h3 class="name">Mett Rayan</h3>
									<div class="role">Manager</div>
									<div class="image">
										<img src="img/content/team-1.jpg" alt="" title="" width="270" height="270">
									</div>
									<div>
										<p>Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet.</p>
										<div class="contact"><b>Email: </b>mett@itembridge.com</div>
										<div class="contact"><b>Phone: </b>11 555 333 77</div>
									</div>
									<div class="social">
										<div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-facebook" href="#"></a></div>
										<div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-twitter" href="#"></a></div>
										<div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-gplus" href="#"></a></div>
										<div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-linkedin" href="#"></a></div>
									</div>
								</div><!-- .employee-hover -->
		  </div><!-- .employee 
		  
		--><div class="col-sm-3 col-md-3 rotation employee">
		<div class="default">
			<div class="image">
				<img src="img/content/team-2.jpg" alt="" title="" width="270" height="270">
			</div>
			<div class="description">
				<div class="vertical">
					<h3 class="name">Jon O. Example</h3>
					<div class="role">Web designer</div>	
				</div>
			</div>
		</div>
		<div class="employee-hover">
			<h3 class="name">Jon O. Example</h3>
			<div class="role">Web designer</div>
			<div class="image">
				<img src="img/content/team-2.jpg" alt="" title="" width="270" height="270">
			</div>
			<div>
				<p>Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet.</p>
				<div class="contact"><b>Email: </b>mett@itembridge.com</div>
				<div class="contact"><b>Phone: </b>11 555 333 77</div>
			</div>
			<div class="social">
				<div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-facebook" href="#"></a></div>
				<div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-twitter" href="#"></a></div>
				<div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-gplus" href="#"></a></div>
				<div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-linkedin" href="#"></a></div>
			</div>
		</div><!-- .employee-hover -->
		  </div><!-- .employee
		  
		--><div class="col-sm-3 col-md-3 rotation employee">
		<div class="default">
			<div class="image">
				<img src="img/content/team-3.jpg" alt="" title="" width="270" height="270">
			</div>
			<div class="description">
				<div class="vertical">
					<h3 class="name">Turanga Leela</h3>
					<div class="role">Graphic designer</div>	
				</div>
			</div>
		</div>
		<div class="employee-hover">
			<h3 class="name">Turanga Leela</h3>
			<div class="role">Graphic designer</div>
			<div class="image">
				<img src="img/content/team-3.jpg" alt="" title="" width="270" height="270">
			</div>
			<div>
				<p>Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet.</p>
				<div class="contact"><b>Email: </b>mett@itembridge.com</div>
				<div class="contact"><b>Phone: </b>11 555 333 77</div>
			</div>
			<div class="social">
				<div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-facebook" href="#"></a></div>
				<div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-twitter" href="#"></a></div>
				<div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-gplus" href="#"></a></div>
				<div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-linkedin" href="#"></a></div>
			</div>
		</div><!-- .employee-hover -->
		  </div><!-- .employee
		  
		--><div class="col-sm-3 col-md-3 rotation employee">
		<div class="default">
			<div class="image">
				<img src="img/content/team-4.jpg" alt="" title="" width="270" height="270">
			</div>
			<div class="description">
				<div class="vertical">
					<h3 class="name">David X. Cohen</h3>
					<div class="role">Developer</div>	
				</div>
			</div>
		</div>
		<div class="employee-hover">
			<h3 class="name">David X. Cohen</h3>
			<div class="role">Developer</div>
			<div class="image">
				<img src="img/content/team-4.jpg" alt="" title="" width="270" height="270">
			</div>
			<div>
				<p>Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet.</p>
				<div class="contact"><b>Email: </b>mett@itembridge.com</div>
				<div class="contact"><b>Phone: </b>11 555 333 77</div>
			</div>
			<div class="social">
				<div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-facebook" href="#"></a></div>
				<div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-twitter" href="#"></a></div>
				<div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-gplus" href="#"></a></div>
				<div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-linkedin" href="#"></a></div>
			</div>
		</div><!-- .employee-hover -->
	</div><!-- .employee -->
</div>
</div>
</div><!-- .full-width-box -->
@stop