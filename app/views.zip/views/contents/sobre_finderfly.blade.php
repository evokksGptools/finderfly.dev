@section('sobre_finderfly')
<div class="container">
	<div class="row">
		<div class="bottom-padding col-sm-12 col-md-12">
			<div class="carousel-box load overflow" data-carousel-pagination="true" data-carousel-nav="false" data-carousel-one="true">
				<div class="title-box">
					<a class="next" href="#">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="9px" height="16px" viewBox="0 0 9 16" enable-background="new 0 0 9 16" xml:space="preserve">
							<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#fcfcfc" points="1,0.001 0,1.001 7,8 0,14.999 1,15.999 9,8 "></polygon>
						</svg>
					</a>
					<a class="prev" href="#">
						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="9px" height="16px" viewBox="0 0 9 16" enable-background="new 0 0 9 16" xml:space="preserve">
							<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#fcfcfc" points="8,15.999 9,14.999 2,8 9,1.001 8,0.001 0,8 "></polygon>
						</svg>
					</a>
					<h2 class="title">Posts</h2>
				</div>

				<div class="clearfix"></div>

				<div class="row">
					<div class="carousel no-responsive">
						<div class="post">
							<h2 class="entry-title"><a href="/blog-view.html">Lorem ipsum dolor sit.</a></h2>
							<div class="entry-content">
								Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi facere earum quis ipsa vitae qui minima esse ducimus dolorum iste nisi laborum repellat dolores dolore debitis adipisci nemo quia autem pariatur a voluptatem dignissimos maiores accusantium nobis tempora consequatur cumque quas ea doloribus deleniti. Quibusdam commodi laboriosam error temporibus iste ipsa soluta distinctio maiores ad totam beatae incidunt veritatis enim? Reiciendis voluptate cupiditate asperiores ratione laboriosam alias mollitia eaque labore aperiam similique reprehenderit assumenda quidem eos explicabo rerum. Porro at ex magni aliquam laborum delectus voluptate officia modi nam et cupiditate culpa asperiores eaque fuga quae. Dolorum commodi labore neque fuga totam voluptate vitae ea laudantium iure quos placeat accusamus.
							</div>

							<div class="entry-meta">
								<span class="autor-name">Mike Example</span>,
								<span class="time">03.11.2012</span>
								<span class="separator">|</span>
								<span class="meta">Posted in <a href="#">Sports</a>, <a href="#">Movies</a></span>
								<span class="comments-link pull-right">
									<a href="#">3 comment(s)</a>
								</span>
							</div>
						</div>

						<div class="post">
							<h2 class="entry-title"><a href="/blog-view.html">Lorem ipsum dolor sit.</a></h2>
							<div class="entry-content">
								Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi facere earum quis ipsa vitae qui minima esse ducimus dolorum iste nisi laborum repellat dolores dolore debitis adipisci nemo quia autem pariatur a voluptatem dignissimos maiores accusantium nobis tempora consequatur cumque quas ea doloribus deleniti. Quibusdam commodi laboriosam error temporibus iste ipsa soluta distinctio maiores ad totam beatae incidunt veritatis enim? Reiciendis voluptate cupiditate asperiores ratione laboriosam alias mollitia eaque labore aperiam similique reprehenderit assumenda quidem eos explicabo rerum. Porro at ex magni aliquam laborum delectus voluptate officia modi nam et cupiditate culpa asperiores eaque fuga quae. Dolorum commodi labore neque fuga totam voluptate vitae ea laudantium iure quos placeat accusamus.
							</div>

							<div class="entry-meta">
								<span class="autor-name">Mike Example</span>,
								<span class="time">03.11.2012</span>
								<span class="separator">|</span>
								<span class="meta">Posted in <a href="#">Sports</a>, <a href="#">Movies</a></span>
								<span class="comments-link pull-right">
									<a href="#">3 comment(s)</a>
								</span>
							</div>
						</div>
					</div>
				</div>

				<div class="clearfix"></div>

				<div class="pagination switches"></div>
			</div>
		</div>
	</div>
</div>
@stop