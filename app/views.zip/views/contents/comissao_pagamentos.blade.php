@section('comissao_pagamentos')
<div class="container">
	<div class="row">
		<div class="col-sm-12 col-md-6 promo-partners bottom-padding">
			<div class="title-box">
				<h2 class="title">Our partners</h2>
			</div>
			<div class="row manufactures manufactures-list">
				<div class="make-wrapper">
					<a href="#" class="make">
						<img src="img/content/make-2.png" width="128" height="128" alt="">
					</a>
			</div><!--
				
		--><div class="make-wrapper">
		<a href="#" class="make">
			<img src="img/content/make-3.png" width="128" height="128" alt="">
		</a>
			</div><!--
				
		--><div class="make-wrapper">
		<a href="#" class="make">
			<img src="img/content/make-4.png" width="128" height="128" alt="">
		</a>
	</div>
</div>
<p>Duis bibendum pulvinar laoreet. Ut eu arcu sit amet elit placerat pharetra sit amet a tortor. Fusce vestibulum auctor rhoncus. Nullam rhoncus, tellus a congue elementum, leo ipsum tincidunt justo, ut condimentum velit eros et lectus. Phasellus ultrices rhoncus vehicula.</p>
<p>Integer ultricies semper massa non condimentum. Phasellus eu ipsum justo. Nullam non pulvinar purus. Ut ante ipsum, venenatis at tristique quis, congue vitae felis. Aliquam cursus diam in massa dapibus auctor. In volutpat, risus non egestas luctus, justo tellus laoreet justo. </p>
</div><!-- .promo-partners -->

<div class="col-sm-12 col-md-6">
	<div class="title-box">
		<a href="#" class="btn btn-default">All posts <span class="glyphicon glyphicon-arrow-right"></span></a>
		<h2 class="title">Latest Posts</h2>
	</div>
	<ul class="latest-posts">
		<li>
			<img class="image img-circle" src="img/content/product-1-84.png" alt="" title="" width="84" height="84" data-appear-animation="rotateIn">
			<div class="meta">
				<span>Mike Example</span>, 
				<span class="time">03.11.2013, 10:45:</span>
			</div>
			<div class="description">
				<a href="#">
					Suspendisse at placerat turpis. Duis luctus erat vel magna pharetra aliquet. Maecenas tincidunt feugiat ultricies. Phasellus et dui risus. 
				</a>
			</div>
		</li>
		<li>
			<img class="image img-circle" src="img/content/product-2-84.png" alt="" title="" width="84" height="84" data-appear-animation="rotateIn">
			<div class="meta">
				<span>Mike Example</span>, 
				<span class="time">03.11.2013, 10:45:</span>
			</div>
			<div class="description">
				<a href="#">
					Maecenas porttitor orci vitae turpis interdum sit amet dignissim dolor consequat. Aenean id erat lorem. 
				</a>
			</div>
		</li>
		<li>
			<img class="image img-circle" src="img/content/product-3-84.png" alt="" title="" width="84" height="84" data-appear-animation="rotateIn">
			<div class="meta">
				<span>Mike Example</span>, 
				<span class="time">03.11.2013, 10:45:</span>
			</div>
			<div class="description">
				<a href="#">
					Mauris vehicula fringilla nisl porttitor sollicitudin. Suspendisse facilisis metus id neque fermentum eget rutrum orci pulvinar.
				</a>
			</div>
		</li>
	</ul>
</div>
</div>
</div>
@stop